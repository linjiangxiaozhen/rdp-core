package pers.rdp.core.sdk.util;

import org.springframework.boot.autoconfigure.web.servlet.WebMvcProperties.View;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

/**
 * 
 * description: 本着最少改动配置的目的，只需要配置这样一个bean就可以了
 * @author xuyfa
 * @date 2019年8月6日 下午3:04:49
 */
@Configuration
@ConfigurationProperties(prefix = "spring.mvc")//获取springboot中jsp视图的配置
public class TestClass {
	// 因为spring.mvc后面还有.vew，这里需要new一个对象，prefix和suffix会注入到这个对象中，同时必须要有getView方法
	private final View view = new View();
	private String[] viewNames;
	public String[] getViewNames() {
		return this.viewNames;
	}

	public void setViewNames(String[] viewNames) {
		this.viewNames = viewNames;
	}
	
	/**
	 * 
	 * description: 以viewResolver命名，阻止ContentNegotiatingViewResolver注入IOC容器，可当做jsp视图解析器
	 * 为什么要阻止ContentNegotiatingViewResolver注入呢，因为这个视图解析器的默认order特别小，总放在集合最前面，它会选择最优视图解析器
	 * @author xuyfa
	 * @date 2019年8月6日 上午11:10:31
	 * @return
	 */
	@Bean
//	@ConditionalOnMissingBean
	public InternalResourceViewResolver viewResolver() {
		InternalResourceViewResolver resolver = new InternalResourceViewResolver();
		resolver.setPrefix(view.getPrefix());
		resolver.setSuffix(view.getSuffix());
		// 这里是重点，设置viewNames,如["jsp/*",""],是个数组（controller返回的时候可以写成"jsp/test"，返回的真实视图名就是 prefix + "jsp/test.jsp"）
		resolver.setViewNames(viewNames);
		// 这个dispatcherServlet处理视图时，视图集合中的排列顺序，我这里放在了thymeleaf和freemarker后面
//		resolver.setOrder(Ordered.LOWEST_PRECEDENCE - 1);
		return resolver;
	}

	public View getView() {
		return view;
	}
	// jsp前缀
//	@Value("${spring.mvc.view.prefix}")
//	private String mvcViewPrefix;
	// jsp后缀
//	@Value("${spring.mvc.view.suffix}")
//	private String mvcViewSuffix;
//	// jsp解析模板排序
//	@Value("${spring.mvc.view.template-resolver-order}")
//	private int mvcViewResolverOrder;
//	// freemarker模板路径
//	@Value("${spring.freemarker.template-loader-path}")
//	private int freemarkerTemplatePath;
//	// freemarker后缀
//	@Value("${spring.freemarker.suffix}")
//	private int freemarkerSuffix;
//	// freemarker解析模板排序
//	@Value("${spring.freemarker.template-resolver-order}")
//	private int freemarkerViewResolverOrder;
//	
//	// thymeleaf模板路径
//	@Value("${spring.thymeleaf.prefix}")
//	private int thymeleafTemplatePath;
//	// freemarker后缀
//	@Value("${spring.thymeleaf.suffix}")
//	private int thymeleafSuffix;
//	// freemarker解析模板排序
//	@Value("${spring.thymeleaf.template-resolver-order}")
//	private int thymeleafViewResolverOrder;
	
//	@Bean
//	@ConditionalOnBean(ViewResolver.class)
//	@ConditionalOnMissingBean(name = "viewResolver", value = ContentNegotiatingViewResolver.class)
//	public ContentNegotiatingViewResolver viewResolver(BeanFactory beanFactory) {
//		ContentNegotiatingViewResolver resolver = new ContentNegotiatingViewResolver();
//		resolver.setContentNegotiationManager(
//				beanFactory.getBean(ContentNegotiationManager.class));
		// ContentNegotiatingViewResolver uses all the other view resolvers to locate
		// a view so it should have a high precedence
//		resolver.setOrder(Ordered.HIGHEST_PRECEDENCE);
//		return resolver;
//	}
	
//	@Bean
//	@ConditionalOnMissingBean(name = "thymeleafViewResolver")
//	public ThymeleafViewResolver viewResolver() {
//		ThymeleafViewResolver resolver = new ThymeleafViewResolver();
//		resolver.setTemplateEngine(templateEngine());
//		resolver.setCharacterEncoding(this.properties.getEncoding().name());
//		resolver.setContentType(
//				appendCharset(this.properties.getServlet().getContentType(),
//						resolver.getCharacterEncoding()));
//		resolver.setProducePartialOutputWhileProcessing(this.properties
//				.getServlet().isProducePartialOutputWhileProcessing());
//		resolver.setExcludedViewNames(this.properties.getExcludedViewNames());
//		resolver.setViewNames(this.properties.getViewNames());
//		// This resolver acts as a fallback resolver (e.g. like a
//		// InternalResourceViewResolver) so it needs to have low precedence
//		resolver.setOrder(Ordered.LOWEST_PRECEDENCE - 5);
//		resolver.setCache(this.properties.isCache());
//		return resolver;
//	}
//	
//	@Bean
//	public ITemplateResolver templateResolver() {
//		SpringResourceTemplateResolver templateResolver = new SpringResourceTemplateResolver();
//        templateResolver.setTemplateMode("HTML5");
//        templateResolver.setPrefix("/WEB-INF/");
//        templateResolver.setSuffix(".html");
//        templateResolver.setCharacterEncoding("utf-8");
//        templateResolver.setCacheable(false);
//        return templateResolver;
//	}
//	
//	@Bean
//	public SpringTemplateEngine templateEngine() {
//		SpringTemplateEngine templateEngine = new SpringTemplateEngine();
//		templateEngine.setTemplateResolver(templateResolver());
//		return templateEngine;
//	}
}
