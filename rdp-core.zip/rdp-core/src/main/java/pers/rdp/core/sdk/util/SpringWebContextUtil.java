package pers.rdp.core.sdk.util;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class SpringWebContextUtil {

	private SpringWebContextUtil() {
	}

	protected static ApplicationContext ctx = null;

	/**
	 * 
	 * description: 根据bean名称从spring IOC中获取bean
	 * @author xuyfa
	 * @date 2019年7月31日 下午3:31:26
	 * @param name
	 * @return
	 */
	public static Object getBean(String name) {
		if (ctx == null) {
			ctx = WebApplicationContextUtils.getRequiredWebApplicationContext(ContextLoader.getCurrentWebApplicationContext().getServletContext());
		}
		return ctx.getBean(name);
	}

	public static void setApplicationContext(ApplicationContext applicationContext) {
		ctx = applicationContext;
	}

	public static ApplicationContext setApplicationContext() {
		ctx = WebApplicationContextUtils.getRequiredWebApplicationContext(ContextLoader.getCurrentWebApplicationContext().getServletContext());
		return ctx;
	}

	/**
	 * 
	 * description: 判断spring容器是否已经初始化
	 * @author xuyfa
	 * @date 2019年7月31日 下午3:41:35
	 * @return
	 */
	public static boolean isContextInited() {
		WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(ContextLoader.getCurrentWebApplicationContext().getServletContext());
		return context != null;
	}
}
