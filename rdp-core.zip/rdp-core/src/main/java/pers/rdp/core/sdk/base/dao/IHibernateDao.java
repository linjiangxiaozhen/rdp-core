package pers.rdp.core.sdk.base.dao;

import java.io.Serializable;
import java.util.List;

import pers.rdp.core.sdk.model.Page;
import pers.rdp.core.sdk.model.Sort;

/**
 * 
 * description: 和service层一样只提供公共方法和泛型方法，
 * 可自行扩展泛型类继承HibernateBaseDao即可
 * @author xuyfa
 * @date 2018年10月12日 上午10:43:47
 */
public interface IHibernateDao {
	/**
	 * 
	 * description: 清除一级缓存
	 * @author xuyfa
	 * @date 2018年10月12日 下午3:29:07
	 */
	void clear();
	
	/**
	 * 
	 * description: 清理缓存，登记要执行的sql，但并未执行commit
	 * @author xuyfa
	 * @date 2018年10月12日 下午3:29:28
	 */
	void flush();
	
	/**
	 * 
	 * description: 清除指定对象缓存
	 * @author xuyfa
	 * @date 2018年10月12日 下午3:34:33
	 * @param object
	 */
	<T> void evict(T entity);
	
	/**
	 * 
	 * description: 保存对象
	 * @author xuyfa
	 * @date 2018年10月12日 下午3:34:54
	 * @param object
	 */
	<T> void save(T entity);
	
	/**
	 * 
	 * description: 批量保存对象
	 * @author xuyfa
	 * @date 2018年10月12日 下午3:35:16
	 * @param objects
	 */
	<T> void save(List<T> entities);
	
	/**
	 * 
	 * description: 保存对象 
	 * @author xuyfa
	 * @date 2018年10月15日 上午9:59:44
	 * @param object
	 */
	<T> void update(T entity);
	
	/**
	 * 
	 * description: 保存或更新
	 * @author xuyfa
	 * @date 2018年10月15日 上午9:59:56
	 * @param object
	 */
	<T> void saveOrUpdate(T entity);
	
	/**
	 * 
	 * description: 批量保存或更新
	 * @author xuyfa
	 * @date 2018年10月15日 上午9:59:56
	 * @param object
	 */
	<T> void saveOrUpdate(List<T> entities);
	
	/**
	 * 
	 * description: 删除 
	 * @author xuyfa
	 * @date 2018年10月15日 上午10:00:22
	 * @param object
	 */
	<T> void delete(T entity);
	
	/**
	 * 
	 * description: 批量删除，发送N条delete sql语句，大批量删除不建议使用此种方式
	 * 大批量使用hql或者sql删除，调用excuteUpdate方式
	 * @author xuyfa
	 * @date 2018年10月15日 上午10:00:22
	 * @param object
	 */
	<T> void delete(List<T> list);
	
	/**
	 * 
	 * description: 批量删除，发送N条delete sql语句，大批量删除不建议使用此种方式，参数可使用List或者数组
	 * 大批量使用hql或者sql删除，调用excuteUpdate方式
	 * @author xuyfa
	 * @date 2018年10月15日 上午10:00:22
	 * @param object
	 */
	<T> void delete(Object... entities);
	
	/**
	 * 
	 * description: 通过id删除记录
	 * @author xuyfa
	 * @date 2018年10月15日 上午10:01:01
	 * @param clazz
	 * @param ids
	 */
	<T> void deleteById(Class<T> clazz, Serializable... ids);
	
	/**
	 * 
	 * description: 通过id调用get方法加载对象 
	 * @author xuyfa
	 * @date 2018年10月15日 上午10:01:27
	 * @param entityClass
	 * @param id
	 * @return
	 */
	<T> T get(Class<T> entityClass, Serializable id);
	
	/**
	 * 
	 * description: 多次调用get方法查询对象，然后添加至集合作为返回结果
	 * 发送N条sql，性能不好，慎用，可使用hql一次性查询from User where 
	 * @author xuyfa
	 * @date 2018年10月15日 上午10:02:11
	 * @param entityClass
	 * @param ids
	 * @return
	 */
	@Deprecated
	<T> List<T> get(Class<T> entityClass, Serializable... ids);
	
	/**
	 * 
	 * description: 通过hql执行update操作，
	 * 如果是hql按参数位置索引赋值，如 update User set name=? where id=?，则parameters请传递一个数组
	 * 如果是hql按参数名称赋值，如 update t_user set name=:name where id=:id，parameters请赋值为HashMap<String, Object>
	 * @author xuyfa
	 * @date 2018年10月15日 上午10:54:22
	 * @param hql
	 * @param parameters
	 * @return
	 */
	int excuteUpdateByHql(String hql, Object... parameters);
	
	/**
	 * 
	 * description: 通过hql执行update操作，hql按参数名称赋值，如 update User where id=:id
	 * @author xuyfa
	 * @date 2018年10月15日 上午10:54:22
	 * @param hql
	 * @param parameters
	 * @return
	 */
//	@Deprecated
//	int excuteUpdateByHql(String hql, Map<String, Object> parameterMap);
	
	/**
	 * 
	 * description: 通过sql执行update操作
	 * 如果是hql按参数位置索引赋值，如 update User set name=? where id=?，则parameters请传递一个数组
	 * 如果是hql按参数名称赋值，如 update t_user set name=:name where id=:id，parameters请赋值为HashMap<String, Object>
	 * @author xuyfa
	 * @date 2018年10月15日 上午10:54:22
	 * @param sql
	 * @param parameters
	 * @return
	 */
	int excuteUpdateBySql(String sql, Object... parameters);
	
	/**
	 * 
	 * description: 通过sql执行update操作，sql按参数名称赋值，如 update User where id=:id
	 * @author xuyfa
	 * @date 2018年10月15日 上午10:54:22
	 * @param sql
	 * @param parameters
	 * @return
	 */
//	@Deprecated
//	int excuteUpdateBySql(String sql, Map<String, Object> parameterMap);
	
	/**
	 * 
	 * description: hql按参数位置索引赋值，如 from User where id=?
	 * 注意：查询部分字段如select name from User where id=?返回结果是List<Object[]>
	 * 如要返回对象，可使用构造函数方式：select new User(name) from User where id=?
	 * 如果是hql按参数位置索引赋值，如 select u from User as u where id=?，则parameters请传递一个数组Object[]
	 * 如果是hql按参数名称赋值，如 select u from User as u where id=:id请赋值为HashMap<String, Object>
	 * @author xuyfa
	 * @date 2018年10月12日 上午11:14:04
	 * @param hql
	 * @param parameters
	 * @return
	 */
	List<?> findByHql(String hql, Object... parameters);
	
	/**
	 * 
	 * description: hql按参数名称赋值，如 from User where id=:id、
	 * 注意：查询部分字段如select name from User where id=:id返回结果是List<Object[]>
	 * 如要返回对象，可使用构造函数方式：select new User(name) from User where id=:id
	 * @author xuyfa
	 * @date 2018年10月12日 上午11:14:04
	 * @param hql
	 * @param parameters
	 * @return
	 */
//	@Deprecated
//	List<?> findByHql(String hql, Map<String, Object> parameterMap);
	
	/**
	 * 
	 * description: sql按参数位置索引赋值，如 select * from user where id=?，则parameters请传递一个数组Object[]
	 * sql按参数名称赋值，如 select * from user where id=:id请赋值为HashMap<String, Object>
	 * @author xuyfa
	 * @date 2018年10月15日 下午2:10:10
	 * @param parameterMap
	 * @return
	 */
	List<?> findBySql(String sql, Class<?> clazz, Object... parameters);
	
	/**
	 * 
	 * description: sql按参数名称赋值，如 select * from user where id=:id
	 * @author xuyfa
	 * @date 2018年10月12日 上午11:54:43
	 * @param queryString
	 * @param values
	 * @return
	 */
//	@Deprecated
//	List<?> findBySql(String sql, Class<?> clazz, Map<String, Object> parameterMap);
	
	/**
	 * 
	 * description: 根据条件查询唯一记录
	 * @author xuyfa
	 * @date 2018年10月15日 下午2:11:25
	 * @param queryString
	 * @param values
	 * @return
	 */
	Object findUniqueByHql(String hql, Object... values);
	
	/**
	 * 
	 * description: sql按参数位置索引赋值，如 select * from user where id=?，则parameters请传递一个数组Object[]
	 * sql按参数名称赋值，如 select * from user where id=:id请赋值为HashMap<String, Object>
	 * @author xuyfa
	 * @date 2018年10月15日 下午4:26:20
	 * @param page 分页对象
	 * @param hql 查询hql
	 * @param sort 排序对象
	 * @param objects 查询参数
	 */
	List<?> findPageResultByHql(Page page, String hql, Sort sort, Object... parameters);
	
	/**
	 * 
	 * description: 按参数名称赋值，如 select * from user where id=:id
	 * @author xuyfa
	 * @date 2018年10月15日 下午4:26:20
	 * @param page 分页对象
	 * @param hql 查询hql
	 * @param sort 排序对象
	 * @param parameterMap 查询参数
	 */
//	@Deprecated
//	List<?> findPageResultByHql(Page page, String hql, Sort sort, Map<String, Object> parameterMap);
	
	/**
	 * 
	 * description: 按参数位置索引赋值，如 select * from user where id=?
	 * 注意：数据库字段通常与java字段名称不一致，如数据库字段：user_name,java字段名称为驼峰userName,书写sql
	 * 时务必给字段取别名，select user_name as userName from t_user
	 * sql按参数位置索引赋值，如 select * from user where id=?，则parameters请传递一个数组Object[]
	 * sql按参数名称赋值，如 select * from user where id=:id请赋值为HashMap<String, Object>
	 * @author xuyfa
	 * @date 2018年10月15日 下午4:26:20
	 * @param page 分页对象
	 * @param sql 查询sql
	 * @param clazz 查询结果转换类，如需要转换成map，可传递参数为java.util.Map.class
	 * @param sort 排序对象
	 * @param objects 查询参数
	 */
	List<?> findPageResultBySql(Page page, String sql, Class<?> clazz, Sort sort, Object... parameters);
	
	/**
	 * 
	 * description: 按参数位置索引赋值，如 select * from user where id=:id
	 * 注意：数据库字段通常与java字段名称不一致，如数据库字段：user_name,java字段名称为驼峰userName,书写sql
	 * 时务必给字段取别名，select user_name as userName from t_user
	 * @author xuyfa
	 * @date 2018年10月15日 下午4:26:20
	 * @param page 分页对象
	 * @param sql 查询sql
	 * @param clazz 查询结果转换类，如需要转换成map，可传递参数为java.util.Map.class
	 * @param sort 排序对象
	 * @param objects 查询参数
	 */
//	@Deprecated
//	List<?> findPageResultBySql(Page page, String sql, Class<?> clazz, Sort sort, Map<String, Object> parameterMap);
	
	/**
	 * 
	 * description: 查询单表所有对象
	 * @author xuyfa
	 * @date 2018年10月16日 上午10:09:38
	 * @param clazz
	 * @return
	 */
	List<?> getObjectAll(Class<?> clazz);
	
	/**
	 * 
	 * description: 物理删除单表所有记录
	 * @author xuyfa
	 * @date 2018年10月16日 上午10:09:59
	 * @param clazz
	 */
	void deleteAllPhysical(Class<?> clazz);
}
