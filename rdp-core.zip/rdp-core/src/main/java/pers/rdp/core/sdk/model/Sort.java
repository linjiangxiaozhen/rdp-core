package pers.rdp.core.sdk.model;

/**
 * 
 * description: 排序字段封装对象
 * 注意：此类没有给出表别名的封装，对于多表查询，要对不同表的字段进行排序，如果出现
 * 相同名称字段，针对hql查询时，要修改名称使之不相同，对于sql查询比较好办，给字段设置别名后，
 * 用别名来排序即可
 * @author xuyfa
 * @date 2018年10月15日 下午4:32:50
 */
public class Sort {
	// 排序字段，中间以逗号分隔，套用easyui参数
	private String fields;
	// 排序方式：升序、降序
	private String orders;

	public String getFields() {
		return fields;
	}

	public void setFields(String fields) {
		this.fields = fields;
	}

	public String getOrders() {
		return orders;
	}

	public void setOrders(String orders) {
		this.orders = orders;
	}


}
