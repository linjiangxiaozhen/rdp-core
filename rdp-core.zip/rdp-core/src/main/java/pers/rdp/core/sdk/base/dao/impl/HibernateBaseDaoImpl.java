package pers.rdp.core.sdk.base.dao.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManagerFactory;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import pers.rdp.core.sdk.base.dao.IHibernateDao;
import pers.rdp.core.sdk.constants.RdpConstants;
import pers.rdp.core.sdk.model.Page;
import pers.rdp.core.sdk.model.Sort;

@Repository("hibernateBaseDao")
public class HibernateBaseDaoImpl implements IHibernateDao {
	@Resource
    private EntityManagerFactory entityManagerFactory;
	protected SessionFactory sessionFactory;
	
	protected Session currentSession() {
		if (this.sessionFactory == null) {
			sessionFactory = this.entityManagerFactory.unwrap(SessionFactory.class);
		}
		return sessionFactory.getCurrentSession();
	}

	@Override
	public void clear() {
		currentSession().clear();
	}

	@Override
	public void flush() {
		currentSession().flush();
	}

	@Override
	public <T> void evict(T entity) {
		currentSession().evict(entity);
	}

	@Override
	public <T> void save(T entity) {
		currentSession().save(entity);
	}

	@Override
	public <T> void save(List<T> entities) {
		this.batchModify(entities, RdpConstants.DAO_SAVE_TAG);
	}

	@Override
	public <T> void update(T entity) {
		currentSession().update(entity);
	}

	@Override
	public <T> void saveOrUpdate(T entity) {
		currentSession().saveOrUpdate(entity);
	}

	@Override
	public <T> void saveOrUpdate(List<T> entities) {
		this.batchModify(entities, RdpConstants.DAO_UPDATE_TAG);
	}

	@Override
	public <T> void delete(T entity) {
		currentSession().delete(entity);
	}

	@Override
	public <T> void delete(List<T> entities) {
		this.batchModify(entities, RdpConstants.DAO_DELETE_TAG);
	}

	@Override
	public <T> void delete(Object... entities) {
		Session currentSession = currentSession();
		for (Object entity : entities) {
			currentSession.delete(entity);
		}
	}

	@Override
	public <T> void deleteById(Class<T> clazz, Serializable... ids) {
		this.delete(this.get(clazz, ids));
	}

	@Override
	public <T> T get(Class<T> clazz, Serializable id) {
		return currentSession().get(clazz, id);
	}

	@Override
	public <T> List<T> get(Class<T> clazz, Serializable... ids) {
		List<T> list = new ArrayList<T>();
		for (Serializable id : ids) {
			list.add(this.get(clazz, id));
		}
		return list;
	}

	@Override
	public int excuteUpdateByHql(String hql, Object... parameters) {
		Query<?> query = this.generateQuery(true, hql, null);
		setQueryParameters(query, parameters);
		return query.executeUpdate();
	}

	@Override
	public int excuteUpdateBySql(String sql, Object... parameters) {
		Query<?> query = this.generateQuery(false, sql, null);
		setQueryParameters(query, parameters);
		return query.executeUpdate();
	}

	@Override
	public List<?> findByHql(String hql, Object... parameters) {
		Query<?> query = this.generateQuery(true, hql, null);
		setQueryParameters(query, parameters);
		return query.getResultList();
	}
	
	@Override
	public List<?> findBySql(String sql, Class<?> clazz, Object... parameters) {
		Query<?> query = this.generateQuery(false, sql, clazz);
		setQueryParameters(query, parameters);
		return query.getResultList();
	}
	
	private void batchModify(List<?> entities, int tag) {
		Iterator<?> it = entities.iterator();
		Session currentSession = currentSession();
		while (it.hasNext()) {
			switch (tag) {
			case RdpConstants.DAO_DELETE_TAG:
				currentSession.delete(it.next());
				break;
			case RdpConstants.DAO_SAVE_TAG:
				currentSession.save(it.next());
				break;
			case RdpConstants.DAO_UPDATE_TAG:
				currentSession.saveOrUpdate(it.next());
				break;
			}
		}
	}

	@Override
	public Object findUniqueByHql(String queryString, Object... values) {
		Query<?> query = this.currentSession().createQuery(queryString);
		setQueryParameters(query, values);
		return query.uniqueResult();
	}
	
	protected void setQueryParameters(Query<?> query, Object... parameters) {
		if (parameters == null || (parameters.length <= 0 || parameters[0] == null)) {
			return;
		}
		if (parameters[0] instanceof Map) {
			query.setProperties(parameters[0]);
			return;
		}
		for (int i = 0; i < parameters.length; i++) {
			query.setParameter(i, parameters[i]);
		}
	}
	
	/**
	 * 
	 * description: 
	 * @author xuyfa
	 * @date 2018年10月15日 下午3:19:28
	 * @param isHqlQuery 是否是HQL
	 * @param queryString 查询语句
	 * @param clazz 查询结果转化类，如不需要转化设置为null即可
	 * @return
	 */
	protected Query<?> generateQuery(Boolean isHqlQuery, String queryString, Class<?> clazz) {
		if (isHqlQuery == null) {
			isHqlQuery = true;
		}
		Session session = this.currentSession();
		if (isHqlQuery) {
			return session.createQuery(queryString);
		} else {
			if (clazz != null) {
				return session.createNativeQuery(queryString, clazz);
			} else {
				return session.createNativeQuery(queryString);
			}
		}
	}

	@Override
	public List<?> findPageResultByHql(Page page, String hql, Sort sort, Object... parameters) {
		StringBuilder sbHql = new StringBuilder(hql);
		if (sort != null && sort.getFields() != null) {
			sbHql.append(" order by ");
			String[] fields = sort.getFields().split(",");
			String[] orders = sort.getOrders().split(",");
			for (int i = 0; i < fields.length; i++) {
				sbHql.append(fields[i]).append(' ').append(orders[i]).append(',');
			}
		}
		hql = sbHql.substring(0, sbHql.length() - 1);
		Query<?> query = this.generateQuery(true, hql, null);
		setQueryParameters(query, parameters);
		List<?> resultList = null;
		if (page != null) {
			page.setTotalCount(getTotalCount(true, hql, parameters));
			query.setFirstResult(page.getFirst() - 1);
			query.setMaxResults(page.getPageSize());
			resultList = query.getResultList();
			page.setResult(resultList);
		}
		return resultList;
	}

	@Override
	public List<?> findPageResultBySql(Page page, String sql, Class<?> clazz, Sort sort, Object... parameters) {
		StringBuilder sbSql = new StringBuilder(sql);
		if (sort != null && sort.getFields() != null) {
			sbSql.append(" order by ");
			String[] fields = sort.getFields().split(",");
			String[] orders = sort.getOrders().split(",");
			for (int i = 0; i < fields.length; i++) {
				sbSql.append(fields[i]).append(' ').append(orders[i]).append(',');
			}
		}
		sql = sbSql.substring(0, sbSql.length() - 2);
		Query<?> query = this.generateQuery(false, sql, clazz);
		setQueryParameters(query, parameters);
		List<?> resultList = null;
		if (page != null) {
			page.setTotalCount(getTotalCount(false, sql, parameters));
			query.setFirstResult(page.getFirst() - 1);
			query.setMaxResults(page.getPageSize());
			resultList = query.getResultList();
			page.setResult(resultList);
		}
		return resultList;
	}
	
//	public int getHqlCount(String sqlContext, Object... parameters) {
//		String hqlLower = sqlContext.toLowerCase();
//		int fromIndex = hqlLower.indexOf(RdpConstants.SQL_KEYWORD_FROM);
//		int selectIndex = hqlLower.indexOf(RdpConstants.SQL_KEYWORD_SELECT);
//		String hql = null;
//		Object[] params = parameters;
//		// 不是以select开头的hql语句
//		if (selectIndex == -1 || selectIndex > fromIndex) {
//			hql = "select count(1) " + sqlContext;
//		} else {// 以select开头的hql
//			// 截取select至from之间的内容
//			String selPart = hqlLower.substring(selectIndex + RdpConstants.SQL_KEYWORD_SELECT_LENGTH,fromIndex);
//			int oldIndex = 0;
//			while (selPart.contains(RdpConstants.SQL_KEYWORD_SELECT)) {
//				oldIndex = fromIndex;
//				fromIndex = hqlLower.indexOf(RdpConstants.SQL_KEYWORD_FROM, fromIndex + RdpConstants.SQL_KEYWORD_FROM_LENGTH);
//				selPart = hqlLower.substring(oldIndex + RdpConstants.SQL_KEYWORD_FROM_LENGTH, fromIndex);
//			}
//			String sql = sqlContext.substring(fromIndex, hqlLower.length());
//			String paramStr = sqlContext.substring(0, fromIndex);
//			int paramCount = paramStr.split("\\?").length;
//			if (paramCount > 1) {
//				params = Arrays.copyOfRange(parameters, paramCount - 1, parameters.length);
//			}
//			hql = "select count(1) " + sql;
//		}
//		if (hql.contains(" order ")) {
//			selectIndex = hql.indexOf(" order ");
//			hql = hql.substring(0, selectIndex);
//		}
//		Query<?> query = this.sessionFactory.getCurrentSession().createQuery(hql);
//		setQueryParameters(query, params);
//		List<?> list = query.list();
//		if (hql.contains("group by") && list != null) {
//			return list.size();
//		}
//		if (list != null && !list.isEmpty()) {
//			return Integer.parseInt(list.get(0).toString());
//		}
//		return 0;
//	}
	
	public int getTotalCount(Boolean isHqlQuery, String queryString, Object... parameters) {
		if (isHqlQuery == null) {
			isHqlQuery = true;
		}
		String hqlLower = queryString.toLowerCase();
		int fromIndex = hqlLower.indexOf(RdpConstants.SQL_KEYWORD_FROM);
		int selectIndex = hqlLower.indexOf(RdpConstants.SQL_KEYWORD_SELECT);
		// 不是以select开头的hql语句
		if (selectIndex == -1 || selectIndex > fromIndex) {
			queryString = "select count(1) " + queryString;
		} else {
			queryString = "select count(1) from (" + queryString + ")";
		}
		Query<?> query = this.generateQuery(isHqlQuery, queryString, null);
		setQueryParameters(query, parameters);
		return Integer.valueOf(query.uniqueResult().toString());
	}

	@Override
	public List<?> getObjectAll(Class<?> clazz) {
		String hql = "from " + clazz.getName();
		return this.findByHql(hql, new Object[]{});
	}

	@Override
	public void deleteAllPhysical(Class<?> clazz) {
		String hql = "delete from " + clazz.getName();
		this.excuteUpdateByHql(hql, new Object[]{});
	}
}
