package pers.rdp.core.sdk.constants;

public class RdpConstants {
	public static final int DAO_DELETE_TAG = 2;
	public static final int DAO_SAVE_TAG = 0;
	public static final int DAO_UPDATE_TAG = 1;
	
	public static final String SQL_KEYWORD_SELECT = "select";
	public static final String SQL_KEYWORD_FROM = "from";
//	public static final int SQL_KEYWORD_SELECT_LENGTH = 6;
//	public static final int SQL_KEYWORD_FROM_LENGTH = 4;
}
