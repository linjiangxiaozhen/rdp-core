package pers.rdp.core.sdk.base.service;

import java.io.Serializable;
import java.util.List;


/**
 * 
 * description:service层不需要提供泛型类模式，只需要提供公共方法或者泛型方法即可，比如在
 * userService中保存对象时既可以保存User对象也可以保存Role对象，毕竟service
 * 是以业务为单位 
 * @author xuyfa
 * @date 2018年10月11日 下午8:28:39
 */
public interface IHibernateBaseService {
	
	/**
	 * 
	 * description: get方法通过id获唯一取对象
	 * @author xuyfa
	 * @date 2018年10月11日 下午6:02:41
	 * @param clazz
	 * @param id
	 * @return
	 */
	<T> T get(Class<T> clazz, final Serializable id);
	
	/**
	 * 
	 * description: 对象保存
	 * @author xuyfa
	 * @date 2018年10月11日 下午6:03:30
	 * @param entity
	 */
	<T> void save(T entity);

	/**
	 * 
	 * description: 删除对象
	 * @author xuyfa
	 * @date 2018年10月11日 下午6:04:22
	 * @param entity
	 */
	<T> void remove(T entity);

	/**
	 * 
	 * description: 对象更新
	 * @author xuyfa
	 * @date 2018年10月11日 下午6:04:27
	 * @param entity
	 */
	<T> void update(T entity);
	
	/**
	 * 
	 * description: 保存或更新
	 * @author xuyfa
	 * @date 2018年10月11日 下午7:15:20
	 * @param entity
	 */
	<T> void saveOrUpdate(T entity);
	
	/**
	 * 
	 * description: 批量保存记录 
	 * @author xuyfa
	 * @date 2018年10月11日 下午7:14:26
	 * @param entities
	 */
	void save(List<?> entities);

	/**
	 * 
	 * description: 批量删除记录
	 * @author xuyfa
	 * @date 2018年10月11日 下午7:12:48
	 * @param entities
	 */
	void remove(List<?> entities);

	/**
	 * 
	 * description: 批量更新
	 * @author xuyfa
	 * @date 2018年10月11日 下午7:11:35
	 * @param entities
	 */
	void update(List<?> entities);
	
	/**
	 * 
	 * description: 批量保存或更新
	 * @author xuyfa
	 * @date 2018年10月11日 下午7:11:08
	 * @param entities
	 */
	void saveOrUpdate(List<?> entities);
	
	/**
	 * 
	 * description: 通过指定的主键移除相应的实体对象
	 * @author xuyfa
	 * @date 2018年10月11日 下午7:12:11
	 * @param clazz
	 * @param id
	 */
//	void removeById(Class<?> clazz, Serializable id);
	
	/**
	 * 
	 * description: 通过指定的主键移除所有相应的实体对象 
	 * @author xuyfa
	 * @date 2018年10月11日 下午7:12:21
	 * @param clazz
	 * @param ids
	 */
	void removeById(Class<?> clazz, Serializable[] ids);
	
	/**
	 * 
	 * description: 查询所有对象
	 * @author xuyfa
	 * @date 2018年10月11日 下午7:07:01
	 * @param clazz
	 * @return
	 */
	List<?> getObjectAll(Class<?> clazz);
	
	/**
	 * 
	 * description: 物理删除所有记录
	 * @author xuyfa
	 * @date 2018年10月11日 下午7:07:10
	 * @param clazz
	 */
	void deleteAllPhysical(Class<?> clazz);
}
