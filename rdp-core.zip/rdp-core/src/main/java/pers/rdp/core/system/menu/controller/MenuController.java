package pers.rdp.core.system.menu.controller;

import org.springframework.stereotype.Controller;

@Controller("/system/menu")
public class MenuController {
	
}
