package pers.rdp.core.sdk.model;

import java.util.List;
import javax.annotation.Generated;
import java.util.Collections;


/**
 * 
 * description: 查询结果集分页包装对象
 * @author xuyfa
 * @date 2018年10月12日 下午1:29:27
 */
public class Page {
	
	// 当前第几页，从第1页开始。
	protected int pageNo = 1;
	// 每页显示的数据个数
	protected int pageSize = 15;
	// 查询结果集
	protected List<?> result;
	// 查询总记录数
	protected long totalCount = 0;
	// 总页数
	protected int totalPages;


	@Generated("SparkTools")
	private Page(Builder builder) {
		this.pageNo = builder.pageNo;
		this.pageSize = builder.pageSize;
		this.result = builder.result;
		this.totalCount = builder.totalCount;
		this.totalPages = builder.totalPages;
	}
	

	public List<?> getResult() {
		return result;
	}

	public void setResult(final List<?> result) {
		this.result = result;
	}
	

	public long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(final long totalCount) {
		this.totalCount = totalCount;
	}

	public long getTotalPages() {
		if (totalCount < 0) {
			return -1;
		}

		long count = totalCount / pageSize;
		if (totalCount % pageSize > 0) {
			count++;
		}
		return count;
	}
	
	public void setTotalPages(final int totalPages) {
		this.totalPages = totalPages;
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	
	public int getFirst() {
		return ((pageNo - 1) * pageSize) + 1;
	}

	/**
	 * Creates builder to build {@link Page}.
	 * @return created builder
	 */
	@Generated("SparkTools")
	public static Builder builder() {
		return new Builder();
	}

	/**
	 * Builder to build {@link Page}.
	 */
	@Generated("SparkTools")
	public static final class Builder {
		private int pageNo;
		private int pageSize;
		private List<?> result = Collections.emptyList();
		private long totalCount;
		private int totalPages;

		private Builder() {
		}

		public Builder withPageNo(int pageNo) {
			this.pageNo = pageNo;
			return this;
		}

		public Builder withPageSize(int pageSize) {
			this.pageSize = pageSize;
			return this;
		}

		public Builder withResult(List<?> result) {
			this.result = result;
			return this;
		}

		public Builder withTotalCount(long totalCount) {
			this.totalCount = totalCount;
			return this;
		}

		public Builder withTotalPages(int totalPages) {
			this.totalPages = totalPages;
			return this;
		}

		public Page build() {
			return new Page(this);
		}
	}
}