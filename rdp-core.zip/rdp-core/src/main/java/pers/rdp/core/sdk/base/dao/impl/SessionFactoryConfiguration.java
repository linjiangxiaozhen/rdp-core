package pers.rdp.core.sdk.base.dao.impl;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SessionFactoryConfiguration {
	//此种写法会造成循环依赖
//	@Bean
//	public SessionFactory sessionFactory(EntityManagerFactory entityManagerFactory) {
//		System.out.println(1111);
//		return entityManagerFactory.unwrap(SessionFactory.class);
//	}
	
//	@Bean
//	public SessionFactory sessionFactory(EntityManagerFactory entityManager) {
//		HibernateEntityManager hEntityManager = (HibernateEntityManager)entityManager;
//        Session session = hEntityManager.get;
//	}
	
}
