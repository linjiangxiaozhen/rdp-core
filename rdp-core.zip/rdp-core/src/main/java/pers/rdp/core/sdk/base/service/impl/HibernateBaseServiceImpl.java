package pers.rdp.core.sdk.base.service.impl;

import java.io.Serializable;
import java.util.List;

import javax.annotation.Resource;

import pers.rdp.core.sdk.base.dao.IHibernateDao;
import pers.rdp.core.sdk.base.service.IHibernateBaseService;

public class HibernateBaseServiceImpl implements IHibernateBaseService{
	@Resource
	private IHibernateDao hibernateBaseDao;

	@Override
	public <T> T get(Class<T> clazz, Serializable id) {
		return this.hibernateBaseDao.get(clazz, id);
	}

	@Override
	public <T> void save(T entity) {
		this.hibernateBaseDao.save(entity);
	}

	@Override
	public <T> void remove(T entity) {
		this.hibernateBaseDao.delete(entity);
	}

	@Override
	public <T> void update(T entity) {
		this.hibernateBaseDao.update(entity);
	}

	@Override
	public <T> void saveOrUpdate(T entity) {
		this.hibernateBaseDao.saveOrUpdate(entity);
	}

	@Override
	public void save(List<?> entities) {
		this.hibernateBaseDao.save(entities);
	}

	@Override
	public void remove(List<?> entities) {
		this.hibernateBaseDao.delete(entities);
	}

	@Override
	public void update(List<?> entities) {
		this.hibernateBaseDao.saveOrUpdate(entities);
	}

	@Override
	public void saveOrUpdate(List<?> entities) {
		this.hibernateBaseDao.saveOrUpdate(entities);
	}

	@Override
	public void removeById(Class<?> clazz, Serializable[] ids) {
		this.hibernateBaseDao.deleteById(clazz, ids);
	}

	@Override
	public List<?> getObjectAll(Class<?> clazz) {
		return this.hibernateBaseDao.getObjectAll(clazz);
	}

	@Override
	public void deleteAllPhysical(Class<?> clazz) {
		this.hibernateBaseDao.deleteAllPhysical(clazz);
	}
	
}
