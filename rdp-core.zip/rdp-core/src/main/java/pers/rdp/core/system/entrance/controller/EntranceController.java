package pers.rdp.core.system.entrance.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/")
public class EntranceController {
	
	@RequestMapping("freemarker/index")
	public String freemarker() {
		return "freemarker/freemarker";
	}
	
	@RequestMapping("jsp/index")
	public String jsp() {
		return "jsp/test111";
	}
	
	@RequestMapping("thymeleaf/index")
	public String thymeleaf() {
		return "thymeleaf/test/thymeleaf";
	}
}
